package com.example.clem.tpfinal

import android.content.Context
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.util.Log

import kotlinx.android.synthetic.main.activity_sensor.*

class SensorActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var mSensorManager: SensorManager
    private lateinit var mSensor: Sensor
    var selectedSensor: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensor)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        Log.i("Message","Sensor Activity started")


        mSensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        selectedSensor = intent.getBooleanExtra(EXTRA_MESSAGE,true)

        if (selectedSensor){
            Log.i("Choix","Light")
            mSensor = mSensorManager?.getDefaultSensor(Sensor.TYPE_LIGHT)

        }
        if(!selectedSensor){
            Log.i("Choix", "Rotation")
            mSensor = mSensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        }
    }

    override fun onResume(){
        super.onResume()
        mSensorManager?.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_NORMAL)

    }

    override fun onSensorChanged(event: SensorEvent) {
        // The light sensor returns a single value.
        // Many sensors return 3 values, one for each axis.

        if(selectedSensor){
            var light = event.values[0]
            // Do something with this sensor value.
            Log.i("Valeur de X",light.toString())
            var myColor = (light/156).toInt()
            val translucentRed = Color.rgb(myColor,myColor,myColor)

            colorView.setBackgroundColor(translucentRed)
        }

        if(!selectedSensor){
            var redColor = ((event.values[0]+1)*127).toInt()
            var greenColor = ((event.values[1]+1)*127).toInt()
            var blueColor = ((event.values[2]+1)*127).toInt()
            // Do something with this sensor value.
            Log.i("Valeur de X",redColor.toString())
            Log.i("Valeur de Y",greenColor.toString())
            Log.i("Valeur de Z",blueColor.toString())


            val translucentRed = Color.rgb(redColor,greenColor,blueColor)

            colorView.setBackgroundColor(translucentRed)
        }



    }


    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
        // Do something here if sensor accuracy changes.
    }

    override fun onPause() {
        super.onPause()
        mSensorManager.unregisterListener(this)
    }

}
