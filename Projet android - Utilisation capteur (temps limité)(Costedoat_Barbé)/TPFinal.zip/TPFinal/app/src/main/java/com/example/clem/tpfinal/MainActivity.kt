package com.example.clem.tpfinal

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        fun useSensor(sensorCalled: Boolean){

            val intent = Intent(this, SensorActivity::class.java).apply{
                putExtra(EXTRA_MESSAGE, sensorCalled)
            }
            startActivity(intent)

        }

        lightButton.setOnClickListener{
            Log.i("Message","You clicked on me!")

            useSensor(true)
        }

        rotButton.setOnClickListener{

            useSensor(false)

        }


    }
}
